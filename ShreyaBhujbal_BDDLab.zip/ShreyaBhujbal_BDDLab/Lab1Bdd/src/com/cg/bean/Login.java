/**This is bean class for login
 * @author sbhujbal
 */
package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Login {

	@FindBy(id = "username")
	private WebElement username;

	@FindBy(id = "password")
	private WebElement password;

	@FindBy(id = "login")
	private WebElement login;

	public String getUsername() {
		return username.getAttribute("values");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return password.getAttribute("values");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void clicklogin() {
		login.click();
	}

}
