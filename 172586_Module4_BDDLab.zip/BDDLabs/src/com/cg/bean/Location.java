package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Location {

	@FindBy(id = "locationId")
	private WebElement locId;

	@FindBy(id = "locationName")
	private WebElement locName;

	public String getlocationId() {
		return locId.getAttribute("values");
	}

	public void setlocationId(String locId) {
		this.locId.sendKeys(locId);
	}

	public String getlocationName() {
		return locName.getAttribute("values");
	}

	public void setlocationName(String locName) {
		this.locName.sendKeys(locName);
	}
}
