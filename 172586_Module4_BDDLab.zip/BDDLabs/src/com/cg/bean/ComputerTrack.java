package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ComputerTrack {

	@FindBy(id = "compName")
	private WebElement computerName;

	@FindBy(id = "diskCapacity")
	private WebElement DiskCapacity;

	@FindBy(id = "memory")
	private WebElement totalMemoryInstalled;

	@FindBy(id = "networkCardNumber")
	private WebElement networkCardNumber;

	@FindBy(id = "networkCardmanu")
	private WebElement networkCard;

	@FindBy(id = "space")
	private WebElement freeSpace;

	@FindBy(id = "os")
	private WebElement operatingSystem;

	@FindBy(id = "osVersion")
	private WebElement version;

	@FindBy(id="submit")
	private WebElement submit;
	
	public String getcomputerName() {
		return computerName.getAttribute("values");
	}

	public void setcomputerName(String computerName) {
		this.computerName.sendKeys(computerName);
	}

	public String getDiskCapacity() {
		return DiskCapacity.getAttribute("values");
	}

	public void setDiskCapacity(String DiskCapacity) {
		this.DiskCapacity.sendKeys(DiskCapacity);
	}

	public String gettotalInstalledMemory() {
		return totalMemoryInstalled.getAttribute("values");
	}

	public void settotalInstalledMemory(String totalMemoryInstalled) {
		this.totalMemoryInstalled.sendKeys(totalMemoryInstalled);
	}

	public String getnetworkCardNumber() {
		return networkCardNumber.getAttribute("values");
	}

	public void setnetworkCardNumber(String networkCardNumber) {
		this.networkCardNumber.sendKeys(networkCardNumber);
	}

	public String getnetworkCardManufacturer() {
		return networkCard.getAttribute("values");
	}

	public void setnetworkCardManufacturer(String networkCard) {
		this.networkCard.sendKeys(networkCard);
	}

	public String getfreeSpaceOnDrive() {
		return freeSpace.getAttribute("values");
	}

	public void setfreeSpaceOnDrive(String freeSpace) {
		this.freeSpace.sendKeys(freeSpace);
	}

	public String getoperatingSystem() {
		return operatingSystem.getAttribute("operatingSystem");
	}

	public void setoperatingSystem(String operatingSystem) {
		this.operatingSystem.sendKeys(operatingSystem);
	}

	public String getosVersion() {
		return version.getAttribute("values");
	}

	public void setosVersion(String version) {
		this.version.sendKeys(version);
	}
	
	public void submit() {
		submit.click();
	}

}
