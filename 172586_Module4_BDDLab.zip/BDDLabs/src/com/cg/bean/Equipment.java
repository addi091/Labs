package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Equipment {

	@FindBy(id = "purchaseMethod")
	private WebElement purchaseMethod;

	@FindBy(id = "seqNumber")
	private WebElement seqNumber;

	@FindBy(id = "deptId")
	private WebElement deptId;

	@FindBy(id = "Status")
	private WebElement status;

	@FindBy(id = "costCenter")
	private WebElement centerCost;

	@FindBy(id = "purchaseDate")
	private WebElement purchaseDate;

	@FindBy(id = "auditIndicator")
	private WebElement indicator;

	@FindBy(id = "auditDate")
	private WebElement auditDate;
	
	@FindBy(id="submit")
	private WebElement submit;
	
	public String getPurchaseMethod() {
		return purchaseMethod.getAttribute("values");
	}

	public void setPurchaseMethod(String purchaseMethod) {
		this.purchaseMethod.sendKeys(purchaseMethod);
	}

	public String getSequenceNumber() {
		return seqNumber.getAttribute("values");
	}

	public void setSequenceNumber(String seqNumber) {
		this.seqNumber.sendKeys(seqNumber);
	}

	public String getDepartmentId() {
		return deptId.getAttribute("values");
	}

	public void setDepartmentId(String deptId) {
		this.deptId.sendKeys(deptId);
	}

	public String getStatus() {
		return status.getAttribute("values");
	}

	public void setStatus(String status) {
		this.status.sendKeys(status);
	}

	public String getCostCenter() {
		return centerCost.getAttribute("values");
	}

	public void setCostCenter(String centerCost) {
		this.centerCost.sendKeys(centerCost);
	}

	public String getPurchaseDate() {
		return purchaseDate.getAttribute("values");
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate.sendKeys(purchaseDate);
	}

	public void auditIndicator() {
		indicator.click();
	}

	public String getAuditDate() {
		return auditDate.getAttribute("value");
	}

	public void setAuditDate(String auditDate) {
		this.auditDate.sendKeys(auditDate);
	}

	public void submit() {
		submit.click();
	}

}
