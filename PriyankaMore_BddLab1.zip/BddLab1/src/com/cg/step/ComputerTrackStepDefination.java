package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Computer;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ComputerTrackStepDefination {

	private WebDriver driver;
	private Computer computer;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on Computer form$")
	public void user_is_on_Computer_form() throws Throwable {
		driver.get("file:///C:/Users/priyamor/bdd/Lab1/html/computer.html");
		Thread.sleep(2000);
		computer = new Computer();
		PageFactory.initElements(driver, computer);
	}

	@When("^user enters url$")
	public void user_enters_url() throws Throwable {

	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {

	}

	@When("^user enters invalid computerName$")
	public void user_enters_invalid_computerName() throws Throwable {
		computer.setComputerName("");
	}

	@Then("^display 'Please fill the Computer Name'$")
	public void display_Please_fill_the_Computer_Name() throws Throwable {
		computer.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid diskCapacity$")
	public void user_enters_invalid_diskCapacity() throws Throwable {
		computer.setComputerName("HP");
		computer.setDiskCapacity("");
	}

	@Then("^display 'Please fill the Disk Capacity'$")
	public void display_Please_fill_the_Disk_Capacity() throws Throwable {
		computer.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid totalInstalledMemory$")
	public void user_enters_invalid_totalInstalledMemory() throws Throwable {
		computer.setComputerName("HP");
		computer.setDiskCapacity("2Tb");
		computer.setTotalInstalledMemory("");
	}

	@Then("^display 'Please fill the Total Installed Memory'$")
	public void display_Please_fill_the_Total_Installed_Memory() throws Throwable {
		computer.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid networkCardNumber$")
	public void user_enters_invalid_networkCardNumber() throws Throwable {
		computer.setComputerName("HP");
		computer.setDiskCapacity("2Tb");
		computer.setTotalInstalledMemory("500gb");
		computer.setNetworkCardNumber("");
	}

	@Then("^display 'Please fill the Network Card Number'$")
	public void display_Please_fill_the_Network_Card_Number() throws Throwable {
		computer.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid networkCardManufacturer$")
	public void user_enters_invalid_networkCardManufacturer() throws Throwable {
		computer.setComputerName("HP");
		computer.setDiskCapacity("2Tb");
		computer.setTotalInstalledMemory("500gb");
		computer.setNetworkCardNumber("1234");
		computer.setNetworkCardManufacturer("");
	}

	@Then("^display 'Please fill the Network Card Manufacturer'$")
	public void display_Please_fill_the_Network_Card_Manufacturer() throws Throwable {
		computer.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid freeSpace$")
	public void user_enters_invalid_freeSpace() throws Throwable {
		computer.setComputerName("HP");
		computer.setDiskCapacity("2Tb");
		computer.setTotalInstalledMemory("500gb");
		computer.setNetworkCardNumber("1234");
		computer.setNetworkCardManufacturer("CISCO");
		computer.setFreeSpace("");
	}

	@Then("^display 'Please fill the Free Space'$")
	public void display_Please_fill_the_Free_Space() throws Throwable {
		computer.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid operatingSystem$")
	public void user_enters_invalid_operatingSystem() throws Throwable {
		computer.setComputerName("HP");
		computer.setDiskCapacity("2Tb");
		computer.setTotalInstalledMemory("500gb");
		computer.setNetworkCardNumber("1234");
		computer.setNetworkCardManufacturer("CISCO");
		computer.setFreeSpace("500gb");
		computer.setOperatingSystem("");
	}

	@Then("^display 'Please fill the Operating System'$")
	public void display_Please_fill_the_Operating_System() throws Throwable {
		computer.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid osVersion$")
	public void user_enters_invalid_osVersion() throws Throwable {
		computer.setComputerName("HP");
		computer.setDiskCapacity("2Tb");
		computer.setTotalInstalledMemory("500gb");
		computer.setNetworkCardNumber("1234");
		computer.setNetworkCardManufacturer("CISCO");
		computer.setFreeSpace("500gb");
		computer.setOperatingSystem("windows");
		computer.setOsVersion("");
	}

	@Then("^display 'Please fill the OS Version'$")
	public void display_Please_fill_the_OS_Version() throws Throwable {
		computer.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		computer.setComputerName("HP");
		computer.setDiskCapacity("2Tb");
		computer.setTotalInstalledMemory("500gb");
		computer.setNetworkCardNumber("1234");
		computer.setNetworkCardManufacturer("CISCO");
		computer.setFreeSpace("500gb");
		computer.setOperatingSystem("windows");
		computer.setOsVersion("10");
	}

	@Then("^show successful submit alert$")
	public void show_successful_submit_alert() throws Throwable {
		computer.clickSubmit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
}
