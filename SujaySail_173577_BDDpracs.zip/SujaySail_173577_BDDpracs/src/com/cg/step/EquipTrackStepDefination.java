package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.CompTrak;
import com.cg.bean.Equipment;
import com.cg.bean.User;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EquipTrackStepDefination {

	private WebDriver driver;
	private Equipment equip;
	

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.close();
	}

	@Given("^User is on Equipment form$")
	public void user_is_on_Equipment_form() throws Throwable {
		driver.get("C:\\Users\\sujsail\\BDD\\Lab1\\html\\equipment.html");
		Thread.sleep(2000);
		equip = new Equipment();
		PageFactory.initElements(driver, equip);
	}

	@When("^user enters invalid purchaseMethod$")
	public void user_enters_invalid_purchaseMethod() throws Throwable {
		equip.setPurchaseMethod("");
	}

	@Then("^display 'Please fill the Purchase Method'$")
	public void display_Please_fill_the_Purchase_Method() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid sequenceNumber$")
	public void user_enters_invalid_sequenceNumber() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("");
	}

	@Then("^display 'Please fill the Sequence Number'$")
	public void display_Please_fill_the_Sequence_Number() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid equipmentCode$")
	public void user_enters_invalid_equipmentCode() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("");
	}

	@Then("^display 'Please fill the Equipment Code'$")
	public void display_Please_fill_the_Equipment_Code() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid deptId$")
	public void user_enters_invalid_deptId() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("");
	}

	@Then("^display 'Please fill the Dept ID'$")
	public void display_Please_fill_the_Dept_ID() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid useStatus$")
	public void user_enters_invalid_useStatus() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(0);
	}

	@Then("^display 'Please fill the Use Status'$")
	public void display_Please_fill_the_Use_Status() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid costCenter$")
	public void user_enters_invalid_costCenter() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("");
	}

	@Then("^display 'Please fill the Cost Center'$")
	public void display_Please_fill_the_Cost_Center() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid installDate$")
	public void user_enters_invalid_installDate() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("");
	}

	@Then("^display 'Please fill the Install Date'$")
	public void display_Please_fill_the_Install_Date() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid auditIndicator$")
	public void user_enters_invalid_auditIndicator() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/4/2019");
		equip.setAuditIndictor("");
	}

	@Then("^display 'Please fill the Audit Indicator'$")
	public void display_Please_fill_the_Audit_Indicator() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid auditDate$")
	public void user_enters_invalid_auditDate() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/4/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("");
	}

	@Then("^display 'Please fill the Audit Date'$")
	public void display_Please_fill_the_Audit_Date() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid stock$")
	public void user_enters_invalid_stock() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("");
	}

	@Then("^display 'Please fill the Stock'$")
	public void display_Please_fill_the_Stock() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	
	@When("^user enters invalid location$")
	public void user_enters_invalid_location() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("2");
		equip.setLocation(0);
	}

	@Then("^display 'Please fill the Location'$")
	public void display_Please_fill_the_Location() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid locationId$")
	public void user_enters_invalid_locationId() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("2");
		equip.setLocation(1);
		equip.setLocationId("");
	}

	@Then("^display 'Please fill the Location ID'$")
	public void display_Please_fill_the_Location_ID() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	
	@When("^User register form$")
	public void user_register_form() throws Throwable {
		equip.setPurchaseMethod("online");
		equip.setSequenceNumber("1234");
		equip.setEquipmentCode("456");
		equip.setDeptId("111");
		equip.setUseStatus(1);
		equip.setCostCenter("11111");
		equip.setInstallDate("12/04/2019");
		equip.setAuditIndictor("Yes");
		equip.setAuditDate("01/04/2019");
		equip.setStock("2");
		equip.setLocation(2);
		equip.setLocationId("123");
	}

	@Then("^show successful register alert$")
	public void show_successful_register_alert() throws Throwable {
		equip.clickRegister();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
}
	
