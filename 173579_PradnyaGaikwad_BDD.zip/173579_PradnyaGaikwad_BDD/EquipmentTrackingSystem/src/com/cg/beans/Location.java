package com.cg.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Location {

	@FindBy(id = "locationId")
	private WebElement locationId;

	@FindBy(id = "locationName")
	private WebElement locationName;

	public String getlocationId() {
		return locationId.getAttribute("values");
	}

	public void setlocationId(String locationId) {
		this.locationId.sendKeys(locationId);
	}

	public String getlocationName() {
		return locationName.getAttribute("values");
	}

	public void setlocationName(String locationName) {
		this.locationName.sendKeys(locationName);
	}
}
