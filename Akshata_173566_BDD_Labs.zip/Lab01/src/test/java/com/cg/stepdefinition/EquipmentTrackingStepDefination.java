package com.cg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Equipment;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EquipmentTrackingStepDefination {

	private WebDriver dri;
	private Equipment eq;
	

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		dri = new ChromeDriver();
	}

	@After
	public void destroy() {
		dri.quit();
	}

	@Given("^User is on Equipment form$")
	public void user_is_on_Equipment_form() throws Throwable {
		dri.get("file:///C:/Users/abadadal/Downloads/Lab1/html/equipmentForm.html");
		Thread.sleep(2000);
		eq = new Equipment();
		PageFactory.initElements(dri, eq);
	}

	@When("^user enters invalid purchaseMethod$")
	public void user_enters_invalid_purchaseMethod() throws Throwable {
		eq.setPurchaseMethod("");
	}

	@Then("^display 'Please fill the Purchase Method'$")
	public void display_Please_fill_the_Purchase_Method() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid sequenceNumber$")
	public void user_enters_invalid_sequenceNumber() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("");
	}

	@Then("^display 'Please fill the Sequence Number'$")
	public void display_Please_fill_the_Sequence_Number() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid equipmentCode$")
	public void user_enters_invalid_equipmentCode() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("");
	}

	@Then("^display 'Please fill the Equipment Code'$")
	public void display_Please_fill_the_Equipment_Code() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid deptId$")
	public void user_enters_invalid_deptId() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("");
	}

	@Then("^display 'Please fill the Dept ID'$")
	public void display_Please_fill_the_Dept_ID() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid useStatus$")
	public void user_enters_invalid_useStatus() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("111");
		eq.setUseStatus(0);
	}

	@Then("^display 'Please fill the Use Status'$")
	public void display_Please_fill_the_Use_Status() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid costCenter$")
	public void user_enters_invalid_costCenter() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("111");
		eq.setUseStatus(1);
		eq.setCostCenter("");
	}

	@Then("^display 'Please fill the Cost Center'$")
	public void display_Please_fill_the_Cost_Center() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid installDate$")
	public void user_enters_invalid_installDate() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("111");
		eq.setUseStatus(1);
		eq.setCostCenter("11111");
		eq.setInstallDate("");
	}

	@Then("^display 'Please fill the Install Date'$")
	public void display_Please_fill_the_Install_Date() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid auditIndicator$")
	public void user_enters_invalid_auditIndicator() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("111");
		eq.setUseStatus(1);
		eq.setCostCenter("11111");
		eq.setInstallDate("12/4/2019");
		eq.setAuditIndictor("");
	}

	@Then("^display 'Please fill the Audit Indicator'$")
	public void display_Please_fill_the_Audit_Indicator() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid auditDate$")
	public void user_enters_invalid_auditDate() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("111");
		eq.setUseStatus(1);
		eq.setCostCenter("11111");
		eq.setInstallDate("12/4/2019");
		eq.setAuditIndictor("Yes");
		eq.setAuditDate("");
	}

	@Then("^display 'Please fill the Audit Date'$")
	public void display_Please_fill_the_Audit_Date() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid stock$")
	public void user_enters_invalid_stock() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("111");
		eq.setUseStatus(1);
		eq.setCostCenter("11111");
		eq.setInstallDate("12/04/2019");
		eq.setAuditIndictor("Yes");
		eq.setAuditDate("01/04/2019");
		eq.setStock("");
	}

	@Then("^display 'Please fill the Stock'$")
	public void display_Please_fill_the_Stock() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	
	@When("^user enters invalid location$")
	public void user_enters_invalid_location() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("111");
		eq.setUseStatus(1);
		eq.setCostCenter("11111");
		eq.setInstallDate("12/04/2019");
		eq.setAuditIndictor("Yes");
		eq.setAuditDate("01/04/2019");
		eq.setStock("2");
		eq.setLocation(0);
	}

	@Then("^display 'Please fill the Location'$")
	public void display_Please_fill_the_Location() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid locationId$")
	public void user_enters_invalid_locationId() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("111");
		eq.setUseStatus(1);
		eq.setCostCenter("11111");
		eq.setInstallDate("12/04/2019");
		eq.setAuditIndictor("Yes");
		eq.setAuditDate("01/04/2019");
		eq.setStock("2");
		eq.setLocation(1);
		eq.setLocationId("");
	}

	@Then("^display 'Please fill the Location ID'$")
	public void display_Please_fill_the_Location_ID() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	
	@When("^User register form$")
	public void user_register_form() throws Throwable {
		eq.setPurchaseMethod("online");
		eq.setSequenceNumber("1234");
		eq.setEquipmentCode("456");
		eq.setDeptId("111");
		eq.setUseStatus(1);
		eq.setCostCenter("11111");
		eq.setInstallDate("12/04/2019");
		eq.setAuditIndictor("Yes");
		eq.setAuditDate("01/04/2019");
		eq.setStock("2");
		eq.setLocation(2);
		eq.setLocationId("123");
	}

	@Then("^show successful register alert$")
	public void show_successful_register_alert() throws Throwable {
		eq.clickRegister();
		Thread.sleep(2000);
		dri.switchTo().alert().accept();
		Thread.sleep(2000);
	}
}
	
