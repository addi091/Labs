package com.cg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.User;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserDetailsStepDefination {

	private WebDriver dri;
	private User users;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		dri = new ChromeDriver();
	}

	@After
	public void destroy() {
		dri.quit();
	}
	
	@Given("^User is on Login form$")
	public void user_is_on_Login_form() throws Throwable {
		dri.get("file:///C:/Users/abadadal/Downloads/Lab1/html/loginform.html");
		Thread.sleep(1000);
		users = new User();
		PageFactory.initElements(dri, users);
	}



	@When("^User selects authorization Type$")
	public void user_selects_authorization_Type() throws Throwable {
		users.selectType(2);
	}

	@Then("^Validate authorization Type$")
	public void validate_authorization_Type() throws Throwable {
		users.clickLogin();
		Thread.sleep(1000);
		dri.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters UserId$")
	public void user_enters_UserId() throws Throwable {
		users.selectType(2);
		users.setUserId("123");
	}

	@Then("^Validate UserId$")
	public void validate_UserId() throws Throwable {
		users.clickLogin();
		Thread.sleep(1000);
		dri.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		users.selectType(2);
		users.setUserId("1234");
		users.setUserPass("abc");
	}

	@Then("^Validate Password$")
	public void validate_Password() throws Throwable {
		users.clickLogin();
		Thread.sleep(1000);
		dri.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	@When("^User login form$")
	public void user_login_form() throws Throwable {
		users.selectType(2);
		users.setUserId("1234");
		users.setUserPass("abcd");
	}

	@Then("^show successful login alert$")
	public void show_successful_login_alert() throws Throwable {
		users.clickLogin();
		Thread.sleep(1000);
		dri.switchTo().alert().accept();
		Thread.sleep(1000);
	}
}
