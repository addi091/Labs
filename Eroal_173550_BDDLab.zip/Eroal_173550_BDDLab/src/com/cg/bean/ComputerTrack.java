package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ComputerTrack {

	@FindBy(id = "compName")
	private WebElement computerName;

	@FindBy(id = "diskCapacity")
	private WebElement DiskCapacity;

	@FindBy(id = "memory")
	private WebElement totalInstalledMemory;

	@FindBy(id = "networkCardNumber")
	private WebElement networkCardNumber;

	@FindBy(id = "networkCardManufacturer")
	private WebElement networkCardManufacturer;

	@FindBy(id = "space")
	private WebElement freeSpaceOnDrive;

	@FindBy(id = "os")
	private WebElement operatingSystem;

	@FindBy(id = "osVersion")
	private WebElement osVersion;

	@FindBy(id="submit")
	private WebElement submit;
	
	public String getomputerName() {
		return computerName.getAttribute("values");
	}

	public void setcomputerName(String computerName) {
		this.computerName.sendKeys(computerName);
	}

	public String getDiskCapacity() {
		return DiskCapacity.getAttribute("values");
	}

	public void setDiskCapacity(String DiskCapacity) {
		this.DiskCapacity.sendKeys(DiskCapacity);
	}

	public String gettotalInstalledMemory() {
		return totalInstalledMemory.getAttribute("values");
	}

	public void settotalInstalledMemory(String totalInstalledMemory) {
		this.totalInstalledMemory.sendKeys(totalInstalledMemory);
	}

	public String getnetworkCardNumber() {
		return networkCardNumber.getAttribute("values");
	}

	public void setnetworkCardNumber(String networkCardNumber) {
		this.networkCardNumber.sendKeys(networkCardNumber);
	}

	public String getnetworkCardManufacturer() {
		return networkCardManufacturer.getAttribute("values");
	}

	public void setnetworkCardManufacturer(String networkCardManufacturer) {
		this.networkCardManufacturer.sendKeys(networkCardManufacturer);
	}

	public String getfreeSpaceOnDrive() {
		return freeSpaceOnDrive.getAttribute("values");
	}

	public void setfreeSpaceOnDrive(String freeSpaceOnDrive) {
		this.freeSpaceOnDrive.sendKeys(freeSpaceOnDrive);
	}

	public String getoperatingSystem() {
		return operatingSystem.getAttribute("operatingSystem");
	}

	public void setoperatingSystem(String operatingSystem) {
		this.operatingSystem.sendKeys(operatingSystem);
	}

	public String getosVersion() {
		return osVersion.getAttribute("values");
	}

	public void setosVersion(String osVersion) {
		this.osVersion.sendKeys(osVersion);
	}
	
	public void submit() {
		submit.click();
	}

}
