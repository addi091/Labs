package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Equipment;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EquipmentStepCucumber {
	private WebDriver driver;
	private Equipment equipment;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver//chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		if (driver != null)
			driver.quit();
	}

	@Given("^user is on add equipment form$")
	public void user_is_on_add_equipment_form() throws Throwable {
		driver.get("file:///C:/Users/tgawhale/sts/EquipmentTracking/html/main.html");
		equipment = new Equipment();
		PageFactory.initElements(driver, equipment);
		equipment.showForm();
	}

	@When("^user enters invalid sequence number$")
	public void user_enters_invalid_sequence_number() throws Throwable {
		equipment.setSequenceNumber("12345");
	}

	@Then("^show sequence number alert$")
	public void show_sequence_number_alert() throws Throwable {
		equipment.submitForm();
		Thread.sleep(2000);
	}

	////////////////////////////////////////////
	@When("^user doesnot enter user id$")
	public void user_doesnot_enter_user_id() throws Throwable {
		equipment.setSequenceNumber("1234512345");
		equipment.setUserId("");

	}

	@Then("^show alert$")
	public void show_alert() throws Throwable {
		equipment.submitForm();
		Thread.sleep(2000);
	}

	@When("^user doesnot enter dept id$")
	public void user_doesnot_enter_dept_id() throws Throwable {
		equipment.setSequenceNumber("1234512345");
		equipment.setUserId("U32145");
		equipment.setDeptId("");
	}

	@When("^user doesnot enter tag number$")
	public void user_doesnot_enter_tag_number() throws Throwable {
		equipment.setSequenceNumber("1234512345");
		equipment.setUserId("U32145");
		equipment.setDeptId("D65347");
		equipment.setEquipmentTag("");
	}

	@When("^user doesnot enter cost center$")
	public void user_doesnot_enter_cost_center() throws Throwable {
		equipment.setSequenceNumber("1234512345");
		equipment.setUserId("U32145");
		equipment.setDeptId("D65347");
		equipment.setEquipmentTag("E98256");
		equipment.setCostCenter("");
	}

	@When("^user doesnot enter installed date$")
	public void user_doesnot_enter_installed_date() throws Throwable {
		equipment.setSequenceNumber("1234512345");
		equipment.setUserId("U32145");
		equipment.setDeptId("D65347");
		equipment.setEquipmentTag("E98256");
		equipment.setCostCenter("CC1265");
		equipment.setInstallationdate("");
	}

	@When("^user doesnot select location$")
	public void user_doesnot_select_location() throws Throwable {
		equipment.setSequenceNumber("1234512345");
		equipment.setUserId("U32145");
		equipment.setDeptId("D65347");
		equipment.setEquipmentTag("E98256");
		equipment.setCostCenter("CC1265");
		equipment.setInstallationdate("12/04/2018");
		equipment.setLocation(0);
	}

	@When("^user doesnot select purchase method$")
	public void user_doesnot_select_purchase_method() throws Throwable {
		equipment.setSequenceNumber("1234512345");
		equipment.setUserId("U32145");
		equipment.setDeptId("D65347");
		equipment.setEquipmentTag("E98256");
		equipment.setCostCenter("CC1265");
		equipment.setInstallationdate("12/04/2018");
		equipment.setLocation(2);
		equipment.setPurchase(0);
	}

	@When("^user doesnot enter audit$")
	public void user_doesnot_enter_audit() throws Throwable {
		equipment.setSequenceNumber("1234512345");
		equipment.setUserId("U32145");
		equipment.setDeptId("D65347");
		equipment.setEquipmentTag("E98256");
		equipment.setCostCenter("CC1265");
		equipment.setInstallationdate("12/04/2018");
		equipment.setLocation(2);
		equipment.setPurchase(1);
		equipment.setAudit("");
	}

	@When("^user enters everything$")
	public void user_enters_everything() throws Throwable {
		equipment.setSequenceNumber("1234512345");
		equipment.setUserId("U32145");
		equipment.setDeptId("D65347");
		equipment.setEquipmentTag("E98256");
		equipment.setCostCenter("CC1265");
		equipment.setInstallationdate("12/04/2018");
		equipment.setLocation(2);
		equipment.setPurchase(1);
		equipment.setAudit("A1234");
	}

}
