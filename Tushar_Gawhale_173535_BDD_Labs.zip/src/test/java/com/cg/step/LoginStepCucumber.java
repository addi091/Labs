package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.User;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepCucumber {

	private WebDriver driver;
	private User user;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver//chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		if (driver != null)
			driver.quit();
	}

	@Given("^User is on Login page$")
	public void user_is_on_Login_page() throws Throwable {
	   driver.get("file:///C:/Users/tgawhale/sts/EquipmentTracking/html/index.html");
	   user = new User();
	   PageFactory.initElements(driver, user);
	}

	@When("^user enters invalid username$")
	public void user_enters_invalid_username() throws Throwable {	    
	    user.setUserId("123");
	}

	@Then("^show username invalid$")
	public void show_username_invalid() throws Throwable {
	    user.submitLogin();
	    Thread.sleep(2000);
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		user.setUserId("12345");
		user.setUserPass("pas");
	}

	@Then("^show password invalid$")
	public void show_password_invalid() throws Throwable {
		user.submitLogin();
		Thread.sleep(2000);
	}

	@When("^user does not select role$")
	public void user_does_not_select_role() throws Throwable {
		user.setUserId("12345");
		user.setUserPass("password");
		user.setAuthorizationType(0);
	}

	@Then("^show role invalid$")
	public void show_role_invalid() throws Throwable {
		user.submitLogin();	 
		Thread.sleep(2000);
	}

	@When("^user enters right credentials$")
	public void user_enters_right_credentials() throws Throwable {
		user.setUserId("12345");
		user.setUserPass("password");
		user.setAuthorizationType(2);	    
	}

	@Then("^show dashboard$")
	public void show_dashboard() throws Throwable {
		user.submitLogin();	  
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
}
