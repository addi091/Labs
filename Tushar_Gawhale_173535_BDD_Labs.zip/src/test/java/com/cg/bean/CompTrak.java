package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CompTrak {
	
	@FindBy(id="txtcomputerName")
	WebElement computerName;
	
	@FindBy(id="txtdiskCapacity")
	WebElement diskCapacity;
	
	@FindBy(id="txttotalInstalledMemory")
	WebElement totalInstalledMemory;
	
	@FindBy(id="txtnetworkCardNumber")
	WebElement networkCardNumber;
	
	@FindBy(id="txtnetworkCardManufacturer")
	WebElement networkCardManufacturer;
	
	@FindBy(id="txtfreeSpace")
	WebElement  freeSpace;
	
	@FindBy(id="txtoperatingSystem")
	WebElement operatingSystem;
	
	@FindBy(id="txtosVersion")
	WebElement osVersion;

	public WebElement getComputerName() {
		return computerName;
	}

	public void setComputerName(WebElement computerName) {
		this.computerName = computerName;
	}

	public WebElement getDiskCapacity() {
		return diskCapacity;
	}

	public void setDiskCapacity(WebElement diskCapacity) {
		this.diskCapacity = diskCapacity;
	}

	public WebElement getTotalInstalledMemory() {
		return totalInstalledMemory;
	}

	public void setTotalInstalledMemory(WebElement totalInstalledMemory) {
		this.totalInstalledMemory = totalInstalledMemory;
	}

	public WebElement getNetworkCardNumber() {
		return networkCardNumber;
	}

	public void setNetworkCardNumber(WebElement networkCardNumber) {
		this.networkCardNumber = networkCardNumber;
	}

	public WebElement getNetworkCardManufacturer() {
		return networkCardManufacturer;
	}

	public void setNetworkCardManufacturer(WebElement networkCardManufacturer) {
		this.networkCardManufacturer = networkCardManufacturer;
	}

	public WebElement getFreeSpace() {
		return freeSpace;
	}

	public void setFreeSpace(WebElement freeSpace) {
		this.freeSpace = freeSpace;
	}

	public WebElement getOperatingSystem() {
		return operatingSystem;
	}

	public void setOperatingSystem(WebElement operatingSystem) {
		this.operatingSystem = operatingSystem;
	}

	public WebElement getOsVersion() {
		return osVersion;
	}

	public void setOsVersion(WebElement osVersion) {
		this.osVersion = osVersion;
	}
	
	
}
