package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Equipment {

	@FindBy(id = "showForm")
	WebElement showButton;
	@FindBy(id = "sequence")
	WebElement sequenceNumber;
	@FindBy(id = "user")
	WebElement userId;
	@FindBy(id = "department")
	WebElement deptId;
	@FindBy(id = "tag")
	WebElement equipmentTag;
	@FindBy(id = "ccenter")
	WebElement costCenter;
	@FindBy(id = "date")
	WebElement installationdate;
	@FindBy(id = "location")
	WebElement location;
	@FindBy(id = "purchase")
	WebElement purchase;
	@FindBy(id = "audit")
	WebElement audit;

	@FindBy(tagName = "form")
	WebElement form;

	public void showForm() {
		this.showButton.click();
	}

	public String getSequenceNumber() {
		return sequenceNumber.getAttribute("value");
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber.sendKeys(sequenceNumber);
	}

	public String getUserId() {
		return userId.getAttribute("value");
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}

	public String getDeptId() {
		return deptId.getAttribute("value");
	}

	public void setDeptId(String deptId) {
		this.deptId.sendKeys(deptId);
	}

	public String getEquipmentTag() {
		return equipmentTag.getAttribute("value");
	}

	public void setEquipmentTag(String equipmentTag) {
		this.equipmentTag.sendKeys(equipmentTag);
	}

	public String getCostCenter() {
		return costCenter.getAttribute("value");
	}

	public void setCostCenter(String costCenter) {
		this.costCenter.sendKeys(costCenter);
	}

	public String getInstallationdate() {
		return installationdate.getAttribute("value");
	}

	public void setInstallationdate(String installationdate) {
		this.installationdate.sendKeys(installationdate);
	}

	public void setLocation(int index) {
		Select select = new Select(location);
		select.selectByIndex(index);
	}

	public void setPurchase(int index) {
		Select select = new Select(purchase);
		select.selectByIndex(index);
	}

	public String getAudit() {
		return audit.getAttribute("value");
	}

	public void setAudit(String audit) {
		this.audit.sendKeys(audit);
	}

	public void submitForm() {
		this.form.submit();
	}
}
