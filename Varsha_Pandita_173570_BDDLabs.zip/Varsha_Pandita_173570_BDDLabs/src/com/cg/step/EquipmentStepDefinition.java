package com.cg.step;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.ComputerTrack;
import com.cg.bean.Equipment;
import com.cg.bean.Location;
import com.cg.bean.Login;
import com.cg.bean.User;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EquipmentStepDefinition {

	private Login login;
	private WebDriver driver;
	private User user;
	private Location location;
	private Equipment equipment;
	private ComputerTrack comp;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\varpandi\\workspaceBDD\\Varsha_Pandita_173570_BDDLabs\\mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.close();
	}

	@Given("^User is on Login page$")
	public void user_is_on_Login_page() throws Throwable {
		
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\Varsha_Pandita_173570_BDDLabs\\html\\index.html";
		driver.get(url);
		login = new Login();
		PageFactory.initElements(driver, login);

	}

	@When("^User Enters Username$")
	public void user_Enters_Username() throws Throwable {
		login.setUsername("var");
		

	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		login.clicklogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User Enters password$")
	public void user_Enters_password() throws Throwable {
		login.setPassword("var");
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		login.setUsername("varsha");
		login.clicklogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		login.setUsername("varsha");
		login.setPassword("varsha");
	}

	@Then("^Show successful alert$")
	public void show_successful_alert() throws Throwable {
		login.clicklogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@Given("^User is on Equipment form$")
	public void user_is_on_Equipment_form() throws Throwable {
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\Varsha_Pandita_173570_BDDLabs\\html\\equipment.html";
		driver.get(url);
		equipment = new Equipment();
		PageFactory.initElements(driver, equipment);
		user = new User();
		PageFactory.initElements(driver, user);
	}

	@When("^user enters url$")
	public void user_enters_url() throws Throwable {
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\Varsha_Pandita_173570_BDDLabs\\html\\equipment.html";

	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\Varsha_Pandita_173570_BDDLabs\\html\\equipment.html";
		driver.get(url);

	}

	@When("^User Enters Purchase Method$")
	public void user_Enters_Purchase_Method() throws Throwable {
		equipment.setPurchaseMethod("");
	}

	@Then("^Validate Purchase Method$")
	public void validate_Purchase_Method() throws Throwable {

	}

	@Then("^Display 'Purchase Method cannot be blank'$")
	public void display_Purchase_Method_cannot_be_blank() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User Enters sequenceNumber$")
	public void user_Enters_sequenceNumber() throws Throwable {
		equipment.setSequenceNumber("");

	}

	@Then("^Validate sequenceNumber$")
	public void validate_sequenceNumber() throws Throwable {
		equipment.setPurchaseMethod("Online");

	}

	@Then("^Display 'Sequence Number cannot be blank'$")
	public void display_Sequence_Number_cannot_be_blank() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^User enters UserId$")
	public void user_enters_UserId() throws Throwable {
		user.setUserId("");
		Thread.sleep(1000);
	}

	@Then("^Validate UserId$")
	public void validate_UserId() throws Throwable {
		equipment.setPurchaseMethod("Online");
		equipment.setSequenceNumber("9098764560");
	}

	@Then("^Display 'User ID cannot be blank'$")
	public void display_User_ID_cannot_be_blank() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^User enters deptId$")
	public void user_enters_deptId() throws Throwable {
		equipment.setDepartmentId("");
	}

	@Then("^Validate deptId$")
	public void validate_deptId() throws Throwable {
		equipment.setPurchaseMethod("Online");
		equipment.setSequenceNumber("9098764560");
		user.setUserId("1234567890");
	}

	@Then("^Display 'Dept ID cannot be blank'$")
	public void display_Dept_ID_cannot_be_blank() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters useStatus$")
	public void user_enters_useStatus() throws Throwable {

	}

	@Then("^Validate useStatus$")
	public void validate_useStatus() throws Throwable {
		equipment.setPurchaseMethod("Online");
		equipment.setSequenceNumber("9098764560");
		user.setUserId("1234567890");
	}

	@Then("^Display ' Use Status cannot be blank'$")
	public void display_Use_Status_cannot_be_blank() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^user enters costCenter$")
	public void user_enters_costCenter() throws Throwable {
		equipment.setCostCenter("");

	}

	@Then("^Validate costCenter$")
	public void validate_costCenter() throws Throwable {
		equipment.setPurchaseMethod("Online");
		equipment.setSequenceNumber("9098764560");
		user.setUserId("1234567890");
		equipment.setDepartmentId("12345678900");
	}

	@Then("^Display 'Cost Center cannot be blank'$")
	public void display_Cost_Center_cannot_be_blank() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^user enters installDate$")
	public void user_enters_installDate() throws Throwable {
		equipment.setPurchaseDate("");
		Thread.sleep(1000);
	}

	@Then("^Validate installDate$")
	public void validate_installDate() throws Throwable {
		equipment.setPurchaseMethod("Online");
		equipment.setSequenceNumber("9098764560");
		user.setUserId("1234567890");
		equipment.setDepartmentId("12345678900");
		equipment.setCostCenter("MagarPatta");
	}

	@Then("^Display 'Install Date cannot be blank'$")
	public void display_Install_Date_cannot_be_blank() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^user enters  auditIndicator$")
	public void user_enters_auditIndicator() throws Throwable {
	}

	@Then("^Validate auditIndicator$")
	public void validate_auditIndicator() throws Throwable {
		equipment.setPurchaseMethod("Online");
		equipment.setSequenceNumber("9098764560");
		user.setUserId("1234567890");
		equipment.setDepartmentId("12345678900");
		equipment.setCostCenter("magarPatta");
		equipment.setPurchaseDate("27/11/1996");
	}

	@Then("^Display 'Audit Indicator cannot be blank'$")
	public void display_Audit_Indicator_cannot_be_blank() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^user enters auditDate$")
	public void user_enters_auditDate() throws Throwable {
		equipment.setAuditDate("");

	}

	@Then("^Validate auditDate$")
	public void validate_auditDate() throws Throwable {
		equipment.setPurchaseMethod("Online");
		equipment.setSequenceNumber("9098764560");
		user.setUserId("1234567890");
		equipment.setDepartmentId("12345678900");
		equipment.setCostCenter("MagarPatta");
		equipment.setPurchaseDate("27/11/1996");
		equipment.auditIndicator();
	}

	@Then("^Display 'Audit Date cannot be blank'$")
	public void display_Audit_Date_cannot_be_blank() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^User submits form$")
	public void user_submits_form() throws Throwable {
		equipment.setPurchaseMethod("Online");
		equipment.setSequenceNumber("9098764560");
		user.setUserId("1234567890");
		equipment.setDepartmentId("12345678900");
		equipment.setCostCenter("MagarPatta");
		equipment.setPurchaseDate("27/11/1996");
		equipment.setAuditDate("27/1196");
		equipment.auditIndicator();
	}

	@Then("^Display successful alert$")
	public void display_successful_alert() throws Throwable {
		equipment.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@Given("^User is on ComputerTracking form$")
	public void user_is_on_ComputerTracking_form() throws Throwable {
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\Varsha_Pandita_173570_BDDLabs\\html\\compTrack.html";
		driver.get(url);
		comp = new ComputerTrack();
		PageFactory.initElements(driver, comp);
	}

	@Then("^Display should be loaded$")
	public void display_should_be_loaded() throws Throwable {
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\Varsha_Pandita_173570_BDDLabs\\html\\compTrack.html";
		driver.get(url);
	}

	@When("^user enters computerName$")
	public void user_enters_computerName() throws Throwable {
		comp.setcomputerName("");
	}

	@Then("^Validate computerName$")
	public void validate_computerName() throws Throwable {

	}

	@Then("^Display 'Computer Name cannot be blank'$")
	public void display_Computer_Name_cannot_be_blank() throws Throwable {
		comp.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters diskCapacity$")
	public void user_enters_diskCapacity() throws Throwable {
		comp.setDiskCapacity("");
	}

	@Then("^Validate diskCapacity$")
	public void validate_diskCapacity() throws Throwable {
		comp.setcomputerName("Dell");

		comp.setfreeSpaceOnDrive("60Gb");
		comp.setnetworkCardNumber("123456");
		comp.setnetworkCardManufacturer("Cisco");
		comp.setoperatingSystem("Windows");
		comp.setosVersion("10");
		comp.settotalInstalledMemory("8GB");
	}

	@Then("^Display 'Disk Capacity cannot be blank'$")
	public void display_Disk_Capacity_cannot_be_blank() throws Throwable {
		comp.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters totalInstalledMemory$")
	public void user_enters_totalInstalledMemory() throws Throwable {
		comp.settotalInstalledMemory("");
	}

	@Then("^Validate totalInstalledMemory$")
	public void validate_totalInstalledMemory() throws Throwable {
		comp.setcomputerName("Dell");
		comp.setDiskCapacity("1000GB");
		comp.setfreeSpaceOnDrive("60Gb");
		comp.setnetworkCardNumber("123456");
		comp.setnetworkCardManufacturer("Cisco");
		comp.setoperatingSystem("Windows");
		comp.setosVersion("10");
		comp.settotalInstalledMemory("8GB");
	}

	@Then("^Display 'Total Installed Memory cannot be blank'$")
	public void display_Total_Installed_Memory_cannot_be_blank() throws Throwable {
		comp.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters  networkCardNumber$")
	public void user_enters_networkCardNumber() throws Throwable {
		comp.setnetworkCardNumber("");
	}

	@Then("^Validate networkCardNumber$")
	public void validate_networkCardNumber() throws Throwable {
		comp.setcomputerName("Dell");
		comp.setDiskCapacity("1000GB");
		comp.setfreeSpaceOnDrive("60Gb");

		comp.setnetworkCardManufacturer("Cisco");
		comp.setoperatingSystem("Windows");
		comp.setosVersion("10");
		comp.settotalInstalledMemory("8GB");
	}

	@Then("^Display 'Card Number cannot be blank'$")
	public void display_Card_Number_cannot_be_blank() throws Throwable {
		comp.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters networkCardManufacturer$")
	public void user_enters_networkCardManufacturer() throws Throwable {
		comp.setnetworkCardManufacturer("");
	}

	@Then("^Validate networkCardManufacturer$")
	public void validate_networkCardManufacturer() throws Throwable {
		comp.setcomputerName("Dell");
		comp.setDiskCapacity("1000GB");
		comp.setfreeSpaceOnDrive("60Gb");
		comp.setnetworkCardNumber("123456");

		comp.setoperatingSystem("Windows");
		comp.setosVersion("10");
		comp.settotalInstalledMemory("8GB");
	}

	@Then("^Display 'Network Card Manufacturer cannot be blank'$")
	public void display_Network_Card_Manufacturer_cannot_be_blank() throws Throwable {
		comp.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters freeSpace$")
	public void user_enters_freeSpace() throws Throwable {
		comp.setfreeSpaceOnDrive("");
	}

	@Then("^Validate freeSpace$")
	public void validate_freeSpace() throws Throwable {
		comp.setcomputerName("Dell");
		comp.setDiskCapacity("1000GB");

		comp.setnetworkCardNumber("123456");
		comp.setnetworkCardManufacturer("Cisco");
		comp.setoperatingSystem("Windows");
		comp.setosVersion("10");
		comp.settotalInstalledMemory("8GB");
	}

	@Then("^Display 'Free Space cannot be blank'$")
	public void display_Free_Space_cannot_be_blank() throws Throwable {
		comp.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters invalid operatingSystem$")
	public void user_enters_invalid_operatingSystem() throws Throwable {
		comp.setoperatingSystem("");
	}

	@Then("^Validate$")
	public void validate() throws Throwable {
		comp.setcomputerName("Dell");
		comp.setDiskCapacity("1000GB");
		comp.setfreeSpaceOnDrive("60Gb");
		comp.setnetworkCardNumber("123456");
		comp.setnetworkCardManufacturer("Cisco");
		comp.setosVersion("10");
		comp.settotalInstalledMemory("8GB");
	}

	@Then("^Display 'Operating System cannot be blank'$")
	public void display_Operating_System_cannot_be_blank() throws Throwable {
		comp.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters osVersion$")
	public void user_enters_osVersion() throws Throwable {

		comp.setosVersion("");
	}

	@Then("^Validate osVersion$")
	public void validate_osVersion() throws Throwable {
		comp.setcomputerName("Dell");
		comp.setDiskCapacity("1000GB");
		comp.setfreeSpaceOnDrive("60Gb");
		comp.setnetworkCardNumber("123456");
		comp.setnetworkCardManufacturer("Cisco");
		comp.setoperatingSystem("Windows");
		comp.settotalInstalledMemory("8GB");
	}

	@Then("^Display 'OS Version cannot be blank'$")
	public void display_OS_Version_cannot_be_blank() throws Throwable {
		comp.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User submits comtrack form$")
	public void user_submits_comtrack_form() throws Throwable {
		comp.setcomputerName("Dell");
		comp.setDiskCapacity("1000GB");
		comp.setfreeSpaceOnDrive("60Gb");
		comp.setnetworkCardNumber("123456");
		comp.setnetworkCardManufacturer("Cisco");
		comp.setoperatingSystem("Windows");
		comp.setosVersion("10");
		comp.settotalInstalledMemory("8GB");
	}

	@Then("^show Added successful alert$")
	public void show_Added_successful_alert() throws Throwable {
		comp.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

}
