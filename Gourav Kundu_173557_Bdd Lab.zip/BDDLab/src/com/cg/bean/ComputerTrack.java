package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ComputerTrack {
	
	@FindBy(id="txtComputerName")
	WebElement computerName;
	
	@FindBy(id="txtDiskCapacity")
	WebElement diskCapacity;
	
	@FindBy(id="txtTotalInstalledMemory")
	WebElement totalInstalledMemory;
	
	@FindBy(id="txtNetworkCardNumber")
	WebElement networkCardNumber;
	
	@FindBy(id="txtNetworkCardManufacturer")
	WebElement networkCardManufacturer;
	
	@FindBy(id="txtFreeSpace")
	WebElement  freeSpace;
	
	@FindBy(id="txtOperatingSystem")
	WebElement operatingSystem;
	
	@FindBy(id="txtOsVersion")
	WebElement osVer;

	@FindBy(id = "submit")
	private WebElement submit;
	
	public String getComputerName() {
		return computerName.getAttribute("value");
	}

	public void setComputerName(String computerName) {
		this.computerName.sendKeys(computerName); 
	}

	public String getDiskCapacity() {
		return diskCapacity.getAttribute("value");
	}

	public void setDiskCapacity(String diskCapacity) {
		this.diskCapacity.sendKeys(diskCapacity);
	}

	public String getTotalInstalledMemory() {
		return totalInstalledMemory.getAttribute("value");
	}

	public void setTotalInstalledMemory(String totalInstalledMemory) {
		this.totalInstalledMemory.sendKeys(totalInstalledMemory);
	}

	public String getNetworkCardNumber() {
		return networkCardNumber.getAttribute("value");
	}

	public void setNetworkCardNumber(String networkCardNumber) {
		this.networkCardNumber.sendKeys(networkCardNumber);
	}

	public String getNetworkCardManufacturer() {
		return networkCardManufacturer.getAttribute("value");
	}

	public void setNetworkCardManufacturer(String networkCardManufacturer) {
		this.networkCardManufacturer.sendKeys(networkCardManufacturer);
	}

	public String getFreeSpace() {
		return freeSpace.getAttribute("value");
	}

	public void setFreeSpace(String freeSpace) {
		this.freeSpace.sendKeys(freeSpace);
	}

	public String getOperatingSystem() {
		return operatingSystem.getAttribute("value");
	}

	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem.sendKeys(operatingSystem);
	}

	public String getOsVer() {
		return osVer.getAttribute("value");
	}

	public void setOsVer(String osVer) {
		this.osVer.sendKeys(osVer);
	}
	
	public void clickSubmit() {
		submit.click();
	}
}
