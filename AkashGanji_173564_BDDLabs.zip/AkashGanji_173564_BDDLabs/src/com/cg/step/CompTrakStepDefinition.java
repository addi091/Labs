package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.CompTrak;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CompTrakStepDefinition {

	private WebDriver driver;
	private CompTrak compTrak;

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on Computer form$")
	public void user_is_on_Computer_form() throws Throwable {
		driver.get("file:///C:/Users/akganji/BDDWorkspace/AkashGanji_173564_BDDLabs/html/conputer.html");
		Thread.sleep(5000);
		compTrak = new CompTrak();
		PageFactory.initElements(driver, compTrak);
	}

	@When("^user enters url$")
	public void user_enters_url() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^user enters invalid computerName$")
	public void user_enters_invalid_computerName() throws Throwable {
      compTrak.setComputerName("");
	}

	@Then("^display 'Please fill the Computer Name'$")
	public void display_Please_fill_the_Computer_Name() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid diskCapacity$")
	public void user_enters_invalid_diskCapacity() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("");
	}

	@Then("^display 'Please fill the Disk Capacity'$")
	public void display_Please_fill_the_Disk_Capacity() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid totalInstalledMemory$")
	public void user_enters_invalid_totalInstalledMemory() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("");
	}

	@Then("^display 'Please fill the Total Installed Memory'$")
	public void display_Please_fill_the_Total_Installed_Memory()
			throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid networkCardNumber$")
	public void user_enters_invalid_networkCardNumber() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("");
	}

	@Then("^display 'Please fill the Network Card Number'$")
	public void display_Please_fill_the_Network_Card_Number() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid networkCardManufacturer$")
	public void user_enters_invalid_networkCardManufacturer() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("");
	}

	@Then("^display 'Please fill the Network Card Manufacturer'$")
	public void display_Please_fill_the_Network_Card_Manufacturer()
			throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid freeSpace$")
	public void user_enters_invalid_freeSpace() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("CISCO");
		compTrak.setFreeSpace("");
	}

	@Then("^display 'Please fill the Free Space'$")
	public void display_Please_fill_the_Free_Space() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid operatingSystem$")
	public void user_enters_invalid_operatingSystem() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("CISCO");
		compTrak.setFreeSpace("500gb");
		compTrak.setOperatingSystem("");
	}

	@Then("^display 'Please fill the Operating System'$")
	public void display_Please_fill_the_Operating_System() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^user enters invalid osVersion$")
	public void user_enters_invalid_osVersion() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("CISCO");
		compTrak.setFreeSpace("500gb");
		compTrak.setOperatingSystem("windows");
		compTrak.setOsVersion("");
	}

	@Then("^display 'Please fill the OS Version'$")
	public void display_Please_fill_the_OS_Version() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		compTrak.setComputerName("Dell");
		compTrak.setDiskCapacity("1Tb");
		compTrak.setTotalInstalledMemory("500gb");
		compTrak.setNetworkCardNumber("1234");
		compTrak.setNetworkCardManufacturer("CISCO");
		compTrak.setFreeSpace("500gb");
		compTrak.setOperatingSystem("windows");
		compTrak.setOsVersion("10");
	}

	@Then("^show successful submit alert$")
	public void show_successful_submit_alert() throws Throwable {
		compTrak.clickSubmit();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(5000);
	}
}
