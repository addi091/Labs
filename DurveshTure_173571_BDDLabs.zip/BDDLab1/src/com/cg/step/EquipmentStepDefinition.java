package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.CompTrack;
import com.cg.bean.Equipment;
import com.cg.bean.Location;
import com.cg.bean.User;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EquipmentStepDefinition {
	WebDriver driver;
	WebElement element;
	CompTrack comp;
	Equipment equipment;
	Location location;
	User user;

	@Before
	public void init() {

		System.setProperty("webdriver.chrome.driver",
				"mydriver\\chromedriver.exe");
		driver = new ChromeDriver();

	}
	
	@After
	public void destroy(){
		driver.close();
	}
	
	@Given("^User is on ComptrackRegistratrion page$")
	public void user_is_on_ComptrackRegistratrion_page() throws Throwable {
		String url="file:///C:/BDD%20workspace/BDDLab1/html/comptrack.html";
		driver.get(url);
		comp= new CompTrack();
		PageFactory.initElements(driver, comp);
		Thread.sleep(1000);
	}

	@When("^User enters computerName$")
	public void user_enters_computerName() throws Throwable {
		comp.setComputerName("");
		Thread.sleep(1000);
	}

	@Then("^Validate computerName$")
	public void validate_computerName() throws Throwable {
		comp.submitform();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters diskCapacity$")
	public void user_enters_diskCapacity() throws Throwable {
		comp.setComputerName("Dell");
		comp.setDiskCapacity("");
		Thread.sleep(1000);
	}

	@Then("^Validate diskCapacity$")
	public void validate_diskCapacity() throws Throwable {
		comp.submitform();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters totalInstalledMemory$")
	public void user_enters_totalInstalledMemory() throws Throwable {
		comp.setComputerName("Dell");
		comp.setDiskCapacity("1tb");
		comp.setTotalInstalledMemory("");
		Thread.sleep(1000);
	}

	@Then("^Validate totalInstalledMemory$")
	public void validate_totalInstalledMemory() throws Throwable {
		comp.submitform();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters networkCardNumber$")
	public void user_enters_networkCardNumber() throws Throwable {
		comp.setComputerName("Dell");
		comp.setDiskCapacity("1tb");
		comp.setTotalInstalledMemory("4gb");
		comp.setNetworkCardNumber("");
		Thread.sleep(1000);
	}

	@Then("^Validate networkCardNumber$")
	public void validate_networkCardNumber() throws Throwable {
		comp.submitform();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters networkCardManufacturer$")
	public void user_enters_networkCardManufacturer() throws Throwable {
		comp.setComputerName("Dell");
		comp.setDiskCapacity("1tb");
		comp.setTotalInstalledMemory("4gb");
		comp.setNetworkCardNumber("1234");
		comp.setNetworkCardManufacturer("");
		Thread.sleep(1000);
	}

	@Then("^Validate networkCardManufacturer$")
	public void validate_networkCardManufacturer() throws Throwable {
		comp.submitform();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters freeSpace$")
	public void user_enters_freeSpace() throws Throwable {
		comp.setComputerName("Dell");
		comp.setDiskCapacity("1tb");
		comp.setTotalInstalledMemory("4gb");
		comp.setNetworkCardNumber("1234");
		comp.setNetworkCardManufacturer("cisco");
		comp.setFreeSpace("");
		Thread.sleep(1000);
	}

	@Then("^Validate freeSpace$")
	public void validate_freeSpace() throws Throwable {
		comp.submitform();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters operatingSystem$")
	public void user_enters_operatingSystem() throws Throwable {
		comp.setComputerName("Dell");
		comp.setDiskCapacity("1tb");
		comp.setTotalInstalledMemory("4gb");
		comp.setNetworkCardNumber("1234");
		comp.setNetworkCardManufacturer("cisco");
		comp.setFreeSpace("600gb");
		comp.setOperatingSystem("");
		Thread.sleep(1000);
	}

	@Then("^Validate operatingSystem$")
	public void validate_operatingSystem() throws Throwable {
		comp.submitform();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters osVersion$")
	public void user_enters_osVersion() throws Throwable {
		comp.setComputerName("Dell");
		comp.setDiskCapacity("1tb");
		comp.setTotalInstalledMemory("4gb");
		comp.setNetworkCardNumber("1234");
		comp.setNetworkCardManufacturer("cisco");
		comp.setFreeSpace("600gb");
		comp.setOperatingSystem("windows10");
		comp.setOsVersion("");
		Thread.sleep(1000);
	}

	@Then("^Validate osVersion$")
	public void validate_osVersion() throws Throwable {
		comp.submitform();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		
	}

	@Given("^User is on equipmentregistratrion page$")
	public void user_is_on_equipmentregistratrion_page() throws Throwable {
		String url="file:///C:/BDD%20workspace/BDDLab1/html/equipmentregister.html";
		driver.get(url);
		equipment= new Equipment();
		location= new Location();
		PageFactory.initElements(driver, equipment);
		Thread.sleep(1000);
	}

	@When("^User enters equipmentTag$")
	public void user_enters_equipmentTag() throws Throwable {
		equipment.setEquipmentTag("");
		Thread.sleep(1000);
	}

	@Then("^Validate equipmentTag$")
	public void validate_equipmentTag() throws Throwable {
		equipment.submitform();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters sequenceNumber$")
	public void user_enters_sequenceNumber() throws Throwable {
		equipment.setEquipmentTag("123");
		equipment.setSequenceNumber("");
		Thread.sleep(1000);
	}

	@Then("^Validate sequenceNumber$")
	public void validate_sequenceNumber() throws Throwable {
		equipment.submitform();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}


	@When("^User enters userId$")
	public void user_enters_userId() throws Throwable {
		equipment.setEquipmentTag("123");
		equipment.setSequenceNumber("987");
		equipment.setUserId("");
		Thread.sleep(1000);
	}

	@Then("^Validate userId$")
	public void validate_userId() throws Throwable {
		equipment.submitform();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters location$")
	public void user_enters_location() throws Throwable {
		equipment.setEquipmentTag("123");
		equipment.setSequenceNumber("987");
		equipment.setUserId("45");
		equipment.setLocation("");
		Thread.sleep(1000);
	}

	@Then("^Validate location$")
	public void validate_location() throws Throwable {
		equipment.submitform();
		Thread.sleep(5000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters quantity$")
	public void user_enters_quantity() throws Throwable {
		equipment.setEquipmentTag("123");
		equipment.setSequenceNumber("987");
		equipment.setUserId("45");
		equipment.setLocation("mumbai");
		equipment.setQuantity("");
		Thread.sleep(1000);
	}

	@Then("^Validate quantity$")
	public void validate_quantity() throws Throwable {
		equipment.submitform();
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
	
	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url="file:///C:/BDD%20workspace/BDDLab1/html/login.html";
		driver.get(url);
		user= new User();
		PageFactory.initElements(driver, user);
		Thread.sleep(1000);
	}

	@When("^User enters username$")
	public void user_enters_username() throws Throwable {
		user.setUserId("");
		Thread.sleep(1000);
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		equipment.submitform();
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		user.setUserId("123");
		user.setUserPass("");
		Thread.sleep(1000);
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		equipment.submitform();
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		Thread.sleep(1000);
	}

	@Then("^show successfull alert$")
	public void show_successfull_alert() throws Throwable {
		user.setUserId("123");
		user.setUserPass("3456");
		user.submitform();
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}
}
