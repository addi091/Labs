package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Location {

	@FindBy(id="location")
	private WebElement location;
	
	@FindBy(id="location")
	private WebElement locationId;
	
	@FindBy(tagName="form")
	private WebElement form;

	public void submitform(){
		this.form.submit();
	}

	public String getLocation() {
		return location.getAttribute("value");
	}

	public void setLocation(String location) {
		this.location.sendKeys(location);;
	}

	public String getLocationId() {
		return locationId.getAttribute("value");
	}

	public void setLocationId(String locationId) {
		this.locationId.sendKeys(locationId);;
	}
	
	
}
