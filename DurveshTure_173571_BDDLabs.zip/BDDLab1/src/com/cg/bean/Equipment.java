package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Equipment {

	@FindBy(id="tag")
	private WebElement equipmentTag;
	
	@FindBy(id="sequence")
	private WebElement sequenceNumber;
	
	@FindBy(id="department")
	private WebElement departmentId;
	
	@FindBy(id="userid")
	private WebElement userId;
	
	@FindBy(id="location")
	private WebElement location;
	
	@FindBy(id="quantity")
	private WebElement quantity;
	
	@FindBy(id="ccenter")
	private WebElement costCenter; 
	
	@FindBy(id="date")
	private WebElement installationDate; 
	
	@FindBy(id="purchaseMethod")
	private WebElement purchaseMethod; 
	
	@FindBy(id="auditDate")
	private WebElement auditDate;
	
	@FindBy(id="audit")
	private WebElement auditIndicator;
	
	@FindBy(id="optradio")
	private WebElement stockStatus;
	
	@FindBy(tagName="form")
	private WebElement form;

	public void submitform(){
		this.form.submit();
	}

	public String getEquipmentTag() {
		return equipmentTag.getAttribute("value");
	}

	public void setEquipmentTag(String equipmentTag) {
		this.equipmentTag.sendKeys(equipmentTag);;
	}

	public String getSequenceNumber() {
		return sequenceNumber.getAttribute("value");
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber.sendKeys(sequenceNumber);;
	}

	public String getDepartmentId() {
		return departmentId.getAttribute("value");
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId.sendKeys(departmentId);
	}

	public String getUserId() {
		return userId.getAttribute("value");
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}

	public String getLocation() {
		return location.getAttribute("value");
	}

	public void setLocation(String location) {
		this.location.sendKeys(location);
	}

	public String getQuantity() {
		return quantity.getAttribute("value");
	}

	public void setQuantity(String quantity) {
		this.quantity.sendKeys(quantity);
	}

	public String getCostCenter() {
		return costCenter.getAttribute("value");
	}

	public void setCostCenter(String costCenter) {
		this.costCenter.sendKeys(costCenter);
	}

	public String getInstallationDate() {
		return installationDate.getAttribute("value");
	}

	public void setInstallationDate(String installationDate) {
		this.installationDate.sendKeys(installationDate);
	}

	public String getPurchaseMethod() {
		return purchaseMethod.getAttribute("value");
	}

	public void setPurchaseMethod(String purchaseMethod) {
		this.purchaseMethod.sendKeys(purchaseMethod);
	}

	public String getAuditDate() {
		return auditDate.getAttribute("value");
	}

	public void setAuditDate(String auditDate) {
		this.auditDate.sendKeys(auditDate);
	}

	public String getAuditIndicator() {
		return auditIndicator.getAttribute("value");
	}

	public void setAuditIndicator(String auditIndicator) {
		this.auditIndicator.sendKeys(auditIndicator);
	}

	public String getStockStatus() {
		return stockStatus.getAttribute("value");
	}

	public void setStockStatus(String stockStatus) {
		this.stockStatus.sendKeys(stockStatus);
	}
	
	
}
