package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class User {

	@FindBy(id="username")
	private WebElement userId;

	@FindBy(id="password")
	private WebElement userPass;
	
	@FindBy(id="role")
	private WebElement authorizationType;
	
	@FindBy(tagName="form")
	private WebElement form;

	public void submitform(){
		this.form.submit();
	}

	public String getUserId() {
		return userId.getAttribute("value");
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);;
	}

	public String getUserPass() {
		return userPass.getAttribute("value");
	}

	public void setUserPass(String userPass) {
		this.userPass.sendKeys(userPass);;
	}

	public String getAuthorizationType() {
		return authorizationType.getAttribute("value");
	}

	public void setAuthorizationType(String authorizationType) {
		this.authorizationType.sendKeys(authorizationType);;
	}
	
	
	
}
