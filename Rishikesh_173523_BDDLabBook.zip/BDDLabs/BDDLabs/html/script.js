function validate() {

		var purchaseMethod = document.getElementById("purchaseMethod").value;
		var sequenceNumber = document.getElementById("seqNumber").value;
		var userId = document.getElementById("userId").value;
		var deptId = document.getElementById("deptId").value;
		var costCenter = document.getElementById("costCenter").value;
		var purchaseDate = document.getElementById("purchaseDate").value;
		var auditIndicator = document.getElementById("auditIndicator");
		var auditDate = document.getElementById("auditDate").value;

		if (purchaseMethod.length < 1) {
			alert("Purchase Name Cannot be Blank");
		} else if (sequenceNumber.length < 10) {
			alert("Sequence Cannot be Blank");
		} else if (userId.length < 1) {
			alert("User ID Cannot be Blank");
		} else if (deptId.length < 1) {
			alert("Department Id Cannot be Blank");
		} else if (costCenter.length < 1) {
			alert("Costcenter Cannot be Blank");
		} else if (purchaseDate.length < 1) {
			alert("Purchase Date Cannot be Blank");
		} else if (auditIndicator.checked == false) {
			alert("Audit Indicator is invalid");
		} else if (auditDate.length < 1) {
			alert("Audit Date Cannot be Blank");
		} else {
			alert("Equipment Added Successfully");
			setTimeout(function() {
				window.location = "compTrack.html"
			});
		}

	}